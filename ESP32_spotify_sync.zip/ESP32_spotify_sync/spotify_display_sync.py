"""
Spotify -> ESP32 OLED bridge
-----------------------------
Runs on your PC/laptop. Logs into Spotify, checks the currently playing
track once per second, and sends the info to the ESP32 over Wi-Fi
whenever something changes (song change, play/pause, or just to keep
progress in sync).

Setup:
    pip install spotipy requests

Before running:
    1. Fill in CLIENT_ID, CLIENT_SECRET below (from the Spotify Developer Dashboard)
    2. Set REDIRECT_URI to match exactly what you registered in the dashboard
       (e.g. http://localhost:.....)
    3. Set ESP32_IP to the IP address printed on the ESP32's Serial Monitor
"""

import time
import requests
import spotipy
from spotipy.oauth2 import SpotifyOAuth

# ---------- CONFIG ----------
CLIENT_ID     = "paste your clint id"
CLIENT_SECRET = "paste your secret client id"
REDIRECT_URI  = "paste the redirected url"
SCOPE         = "user-read-currently-playing user-read-playback-state"

ESP32_IP = "get the ip from the serial monitor"          # <-- change to your ESP32's IP
ESP32_URL = f"http://{ESP32_IP}/update"

POLL_INTERVAL_SECONDS = 1
REQUEST_TIMEOUT_SECONDS = 2

# ---------- SPOTIFY AUTH ----------
sp = spotipy.Spotify(auth_manager=SpotifyOAuth(
    client_id=CLIENT_ID,
    client_secret=CLIENT_SECRET,
    redirect_uri=REDIRECT_URI,
    scope=SCOPE,
    open_browser=True,
))


def get_current_track():
    """Returns a dict with track info, or None if nothing is playing."""
    try:
        result = sp.current_playback()
    except Exception as e:
        print(f"[Spotify API error] {e}")
        return None

    if result is None or result.get("item") is None:
        return None

    item = result["item"]
    return {
        "id":       item.get("id", ""),
        "title":    item.get("name", "Unknown"),
        "artist":   ", ".join(a["name"] for a in item.get("artists", [])),
        "duration": item.get("duration_ms", 0),
        "progress": result.get("progress_ms", 0),
        "playing":  result.get("is_playing", False),
    }


def send_to_esp32(track):
    payload = {
        "title":    track["title"],
        "artist":   track["artist"],
        "duration": track["duration"],
        "progress": track["progress"],
        "playing":  "true" if track["playing"] else "false",
    }
    try:
        requests.post(ESP32_URL, data=payload, timeout=REQUEST_TIMEOUT_SECONDS)
        print(f"Sent: {track['title']} - {track['artist']} "
              f"({'Playing' if track['playing'] else 'Paused'})")
    except requests.exceptions.RequestException as e:
        print(f"[ESP32 send error] {e}")


def main():
    print("Starting Spotify -> ESP32 bridge...")
    print(f"Sending updates to {ESP32_URL}")

    last_track_id = None
    last_playing_state = None

    while True:
        track = get_current_track()

        if track is None:
            # nothing playing - only send once when state changes to avoid spamming
            if last_track_id is not None:
                send_to_esp32({
                    "title": "Nothing playing",
                    "artist": "",
                    "duration": 0,
                    "progress": 0,
                    "playing": False,
                })
                last_track_id = None
                last_playing_state = None
        else:
            song_changed = track["id"] != last_track_id
            play_state_changed = track["playing"] != last_playing_state

            # Send on song change / play-pause toggle, and periodically
            # (every ~5s) anyway to keep the progress bar in sync.
            if song_changed or play_state_changed or int(time.time()) % 5 == 0:
                send_to_esp32(track)

            last_track_id = track["id"]
            last_playing_state = track["playing"]

        time.sleep(POLL_INTERVAL_SECONDS)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped.")
