/*
  Spotify Now Playing Display for ESP32 + SSD1306 OLED
  -----------------------------------------------------
  - Connects to Wi-Fi
  - Runs a small web server
  - Receives POST /update from a Python script running on your PC
  - Displays: title, artist, time, progress bar, playing/paused state
  - Scrolls long titles/artists automatically

  Wiring (I2C):
    OLED VCC -> 3.3V
    OLED GND -> GND
    OLED SDA -> GPIO 21
    OLED SCL -> GPIO 22

  Required libraries (install via Library Manager):
    - Adafruit SSD1306
    - Adafruit GFX
    (WiFi.h and WebServer.h come with the ESP32 board package)
*/

#include <WiFi.h>
#include <WebServer.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// ---------- CONFIG ----------
const char* WIFI_SSID     = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET    -1
#define SCREEN_ADDRESS 0x3C   // common address for 0.96" SSD1306; try 0x3D if this doesn't work

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
WebServer server(80);

// ---------- STATE ----------
String  currentTitle    = "No song playing";
String  currentArtist   = "";
long    durationMs      = 0;
long    progressMs      = 0;
bool    isPlaying       = false;
unsigned long lastDataMs = 0;   // last time we received data from PC

// scrolling text state (for title)
int scrollOffset = 0;
unsigned long lastScrollMs = 0;
const int SCROLL_INTERVAL = 200; // ms between scroll steps

// local progress interpolation so the bar moves smoothly between updates
unsigned long lastProgressUpdateMs = 0;

// ---------- HELPERS ----------
String formatTime(long ms) {
  if (ms < 0) ms = 0;
  long totalSeconds = ms / 1000;
  int minutes = totalSeconds / 60;
  int seconds = totalSeconds % 60;
  char buf[8];
  sprintf(buf, "%02d:%02d", minutes, seconds);
  return String(buf);
}

void drawProgressBar(long prog, long dur) {
  int barX = 4, barY = 46, barW = 120, barH = 8;
  display.drawRect(barX, barY, barW, barH, SSD1306_WHITE);
  if (dur > 0) {
    int fillW = (int)(((float)prog / (float)dur) * (barW - 2));
    if (fillW < 0) fillW = 0;
    if (fillW > barW - 2) fillW = barW - 2;
    display.fillRect(barX + 1, barY + 1, fillW, barH - 2, SSD1306_WHITE);
  }
}

void drawDisplay() {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);

  // header
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.print("Spotify");
  display.drawLine(0, 10, 128, 10, SSD1306_WHITE);

  // title (scrolling if too long)
  display.setTextSize(1);
  display.setCursor(0, 16);
  String title = currentTitle;
  int titleWidthPx = title.length() * 6; // approx 6px per char at text size 1
  if (titleWidthPx > SCREEN_WIDTH) {
    String padded = title + "     " + title; // loop it
    int start = scrollOffset % (titleWidthPx + 30);
    // crude character-based scroll
    int charOffset = start / 6;
    display.print(padded.substring(charOffset, charOffset + 21));
  } else {
    display.print(title);
  }

  // artist
  display.setCursor(0, 26);
  display.print(currentArtist);

  // time
  display.setCursor(0, 36);
  display.print(formatTime(progressMs));
  display.print(" / ");
  display.print(formatTime(durationMs));

  // progress bar
  drawProgressBar(progressMs, durationMs);

  // status
  display.setCursor(0, 56);
  if (millis() - lastDataMs > 15000) {
    display.print("Waiting for PC...");
  } else {
    display.print(isPlaying ? "Playing" : "Paused");
  }

  display.display();
}

// ---------- WEB SERVER HANDLERS ----------
void handleUpdate() {
  if (server.hasArg("title"))    currentTitle  = server.arg("title");
  if (server.hasArg("artist"))   currentArtist = server.arg("artist");
  if (server.hasArg("duration")) durationMs    = server.arg("duration").toInt();
  if (server.hasArg("progress")) progressMs    = server.arg("progress").toInt();
  if (server.hasArg("playing"))  isPlaying     = server.arg("playing") == "true";

  lastDataMs = millis();
  lastProgressUpdateMs = millis();
  scrollOffset = 0; // reset scroll on every update (new song or resync)

  server.send(200, "text/plain", "OK");
}

void handleRoot() {
  server.send(200, "text/plain", "ESP32 Spotify Display is running");
}

// ---------- SETUP / LOOP ----------
void setup() {
  Serial.begin(115200);

  if (!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) {
    Serial.println("SSD1306 allocation failed");
    for (;;); // halt
  }
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("Connecting to");
  display.println("Wi-Fi...");
  display.display();

  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi Connected!");
  Serial.print("IP Address: ");
  Serial.println(WiFi.localIP());

  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("WiFi Connected!");
  display.println();
  display.println(WiFi.localIP());
  display.display();
  delay(2000);

  server.on("/", handleRoot);
  server.on("/update", HTTP_POST, handleUpdate);
  server.begin();
  Serial.println("HTTP server started");
}

void loop() {
  server.handleClient();

  // advance local progress estimate so the bar moves even between
  // 1-second updates from the PC (only while playing)
  static unsigned long lastTick = millis();
  unsigned long now = millis();
  if (isPlaying && now - lastTick >= 1000) {
    progressMs += (now - lastTick);
    if (progressMs > durationMs) progressMs = durationMs;
    lastTick = now;
  } else {
    lastTick = now;
  }

  // scroll animation tick
  if (now - lastScrollMs > SCROLL_INTERVAL) {
    scrollOffset += 6;
    lastScrollMs = now;
  }

  drawDisplay();
  delay(50);
}
